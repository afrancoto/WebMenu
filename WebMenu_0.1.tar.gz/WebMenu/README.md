RHYTHMBOX Web Menu
==================

DESCRIPTION: Rhythmbox v2.9x plugin to search on the web for the Youtube video of the current playing song and/or the Wikipedia page of the album.

DOWNLOAD: GET THE LAST VERSION HERE: https://github.com/afrancoto/WebMenu/downloads

INSTALLATION: 1) Extract the archive in ~/.local/share/rhythmbox/plugins 
	      2) Open Rhythmbox: Edit -> Plugins
   	      3) Scroll to WebMenu and check Enabled

USE: A new menu called "Web" will show up on Rhythmbox Menu Bar. You can also use those keyboard shortcuts: (Alt + Y) to search the song on Youtube, (Alt + W) to search the album on Wikipedia.

BUGS AND SUGGESTIONS: Find a bug? Have a suggestion? Throw an issue via Git or write me an e-mail!

Andrea Franco <a.franco.to@gmail.com>

------
COPYRIGHT: This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/.


